import { StreamServer } from '../types';

export const STREAM_SERVERS: StreamServer[] = [
  {
    id: '123embed',
    name: 'Server 1 (123Embed Ultra HD)',
    badge: '🎬 Full Movie HD',
    tag: 'Direct JWPlayer Stream • Multi-Language Subtitles • 100% Full Length Film',
    isPopular: true,
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://play2.123embed.net/tv/${id}/${season}/${episode}`;
      }
      return `https://play2.123embed.net/movie/${id}`;
    },
  },
  {
    id: 'anyembed',
    name: 'Server 2 (AnyEmbed / SmashyStream)',
    badge: '⚡ Fast HLS Full Movie',
    tag: 'Multi-CDN Adaptive Bitrate • Complete Movie & Series • High Speed',
    isPopular: true,
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://anyembed.xyz/embed/tmdb-tv-${id}-${season}-${episode}`;
      }
      return `https://anyembed.xyz/embed/tmdb-movie-${id}`;
    },
  },
  {
    id: 'autoembed',
    name: 'Server 3 (AutoEmbed CC)',
    badge: '🌟 Multi-Source',
    tag: 'Full Movie Engine • Auto Failover Mirrors • Dolby Audio',
    isPopular: true,
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://autoembed.co/movie/tmdb/${id}`;
      }
      return `https://autoembed.co/tv/tmdb/${id}-${season}-${episode}`;
    },
  },
  {
    id: 'videasy',
    name: 'Server 4 (Videasy HD)',
    badge: '1080p Stream',
    tag: 'Videasy High Definition Stream • Complete Full Length',
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://player.videasy.to/tv/${id}/${season}/${episode}`;
      }
      return `https://player.videasy.to/movie/${id}`;
    },
  },
  {
    id: 'vidsrc_pm',
    name: 'Server 5 (VidSrc Prime)',
    badge: 'VidSrc VIP',
    tag: 'Official VidSrc Full Film Library Mirror',
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://vidsrc.pm/embed/tv/${id}/${season}/${episode}`;
      }
      return `https://vidsrc.pm/embed/movie/${id}`;
    },
  },
  {
    id: 'twoembed',
    name: 'Server 6 (2Embed Skin)',
    badge: 'Ultra HD',
    tag: '2Embed Full HD Video Player',
    getUrl: (mediaType, id, season = 1, episode = 1) => {
      if (mediaType === 'tv') {
        return `https://www.2embed.skin/tv/${id}/${season}/${episode}`;
      }
      return `https://www.2embed.skin/movie/${id}`;
    },
  },
];

export function getStreamUrl(
  serverId: string,
  mediaType: 'movie' | 'tv',
  id: number | string,
  season: number = 1,
  episode: number = 1
): string {
  const server = STREAM_SERVERS.find((s) => s.id === serverId) || STREAM_SERVERS[0];
  return server.getUrl(mediaType, id, season, episode);
}

export function getServerById(serverId: string): StreamServer {
  return STREAM_SERVERS.find((s) => s.id === serverId) || STREAM_SERVERS[0];
}
