import { MediaItem, TVSeason } from '../types';
import { loadSettings } from './storage';

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
export const TMDB_IMAGE_ORIGINAL = 'https://image.tmdb.org/t/p/original';
export const TMDB_IMAGE_W500 = 'https://image.tmdb.org/t/p/w500';
export const TMDB_IMAGE_W300 = 'https://image.tmdb.org/t/p/w300';

export function createSlug(title: string): string {
  if (!title) return 'movie';
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function getApiKey(): string {
  return loadSettings().tmdbApiKey || 'abdde991ce2a56652d4c0ca156db7836';
}

// Fallback data for 12 Angry Men (id 389) and popular staples
const FALLBACK_12_ANGRY_MEN: MediaItem = {
  id: 389,
  title: '12 Angry Men',
  original_title: '12 Angry Men',
  overview:
    'The defense and the prosecution have rested and the jury is filing into the jury room to decide if a young Spanish-American is guilty or innocent of murdering his father. What begins as an open-and-shut case of murder soon becomes a mini-drama of each of the jurors’ prejudices and preconceptions about the trial, the accused, and each other.',
  poster_path: '/ow3wq89wM8qd5X7hWKxiRfsFf9C.jpg',
  backdrop_path: '/qqHQsStV6exghCM7zbObuYBiYxw.jpg',
  release_date: '1957-04-10',
  vote_average: 8.548,
  vote_count: 8520,
  media_type: 'movie',
  runtime: 96,
  genres: [
    { id: 18, name: 'Drama' },
    { id: 80, name: 'Crime' },
  ],
  tagline: 'Life is in their hands. Death is on their minds.',
};

export async function fetchTrending(
  mediaType: 'movie' | 'tv' = 'movie',
  timeWindow: 'day' | 'week' = 'day'
): Promise<MediaItem[]> {
  try {
    const key = getApiKey();
    const res = await fetch(`${TMDB_BASE_URL}/trending/${mediaType}/${timeWindow}?api_key=${key}&language=en-US`);
    if (!res.ok) throw new Error(`TMDB responded with status ${res.status}`);
    const data = await res.json();
    return (data.results || []).map((item: any) => ({
      ...item,
      media_type: item.media_type || mediaType,
    }));
  } catch (err) {
    console.warn('Error fetching trending from TMDB:', err);
    return [FALLBACK_12_ANGRY_MEN];
  }
}

export async function fetchTopRated(mediaType: 'movie' | 'tv' = 'movie'): Promise<MediaItem[]> {
  try {
    const key = getApiKey();
    const endpoint = mediaType === 'tv' ? '/tv/top_rated' : '/movie/top_rated';
    const res = await fetch(`${TMDB_BASE_URL}${endpoint}?api_key=${key}&language=en-US&page=1`);
    if (!res.ok) throw new Error(`TMDB error ${res.status}`);
    const data = await res.json();
    return (data.results || []).map((item: any) => ({
      ...item,
      media_type: mediaType,
    }));
  } catch (err) {
    console.warn('Error fetching top rated:', err);
    return [FALLBACK_12_ANGRY_MEN];
  }
}

export async function fetchPopular(mediaType: 'movie' | 'tv' = 'movie'): Promise<MediaItem[]> {
  try {
    const key = getApiKey();
    const endpoint = mediaType === 'tv' ? '/tv/popular' : '/movie/popular';
    const res = await fetch(`${TMDB_BASE_URL}${endpoint}?api_key=${key}&language=en-US&page=1`);
    if (!res.ok) throw new Error(`TMDB error ${res.status}`);
    const data = await res.json();
    return (data.results || []).map((item: any) => ({
      ...item,
      media_type: mediaType,
    }));
  } catch (err) {
    console.warn('Error fetching popular:', err);
    return [];
  }
}

export async function fetchNowPlaying(): Promise<MediaItem[]> {
  try {
    const key = getApiKey();
    const res = await fetch(`${TMDB_BASE_URL}/movie/now_playing?api_key=${key}&language=en-US&page=1`);
    if (!res.ok) throw new Error(`TMDB error ${res.status}`);
    const data = await res.json();
    return (data.results || []).map((item: any) => ({
      ...item,
      media_type: 'movie',
    }));
  } catch (err) {
    console.warn('Error fetching now playing:', err);
    return [];
  }
}

export async function searchMedia(query: string): Promise<MediaItem[]> {
  if (!query || query.trim().length < 2) return [];
  try {
    const key = getApiKey();
    const res = await fetch(
      `${TMDB_BASE_URL}/search/multi?api_key=${key}&query=${encodeURIComponent(query)}&language=en-US&page=1&include_adult=false`
    );
    if (!res.ok) throw new Error(`TMDB search error ${res.status}`);
    const data = await res.json();
    return (data.results || []).filter(
      (item: any) => (item.media_type === 'movie' || item.media_type === 'tv') && item.poster_path
    );
  } catch (err) {
    console.warn('Error searching TMDB:', err);
    return [];
  }
}

export async function fetchMediaDetails(
  id: number | string,
  mediaType: 'movie' | 'tv' = 'movie'
): Promise<MediaItem | null> {
  try {
    const key = getApiKey();
    const endpoint = mediaType === 'tv' ? `/tv/${id}` : `/movie/${id}`;
    const res = await fetch(
      `${TMDB_BASE_URL}${endpoint}?api_key=${key}&language=en-US&append_to_response=credits,videos,similar`
    );
    if (!res.ok) {
      if (Number(id) === 389) return FALLBACK_12_ANGRY_MEN;
      throw new Error(`TMDB details error ${res.status}`);
    }
    const data = await res.json();
    return {
      ...data,
      media_type: mediaType,
    };
  } catch (err) {
    console.warn('Error fetching details:', err);
    if (Number(id) === 389) return FALLBACK_12_ANGRY_MEN;
    return null;
  }
}

export async function fetchTVSeason(tvId: number | string, seasonNumber: number): Promise<TVSeason | null> {
  try {
    const key = getApiKey();
    const res = await fetch(`${TMDB_BASE_URL}/tv/${tvId}/season/${seasonNumber}?api_key=${key}&language=en-US`);
    if (!res.ok) throw new Error(`TMDB season error ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('Error fetching TV season:', err);
    return null;
  }
}

export const GENRE_MAP: { [key: number]: string } = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  99: 'Documentary',
  18: 'Drama',
  10751: 'Family',
  14: 'Fantasy',
  36: 'History',
  27: 'Horror',
  10402: 'Music',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Sci-Fi',
  53: 'Thriller',
  10752: 'War',
  37: 'Western',
};

export async function fetchByGenre(genreId: number, mediaType: 'movie' | 'tv' = 'movie'): Promise<MediaItem[]> {
  try {
    const key = getApiKey();
    const endpoint = mediaType === 'tv' ? '/discover/tv' : '/discover/movie';
    const res = await fetch(
      `${TMDB_BASE_URL}${endpoint}?api_key=${key}&with_genres=${genreId}&sort_by=popularity.desc&page=1`
    );
    if (!res.ok) throw new Error(`TMDB genre fetch error ${res.status}`);
    const data = await res.json();
    return (data.results || []).map((item: any) => ({
      ...item,
      media_type: mediaType,
    }));
  } catch (err) {
    console.warn('Error fetching genre:', err);
    return [];
  }
}
