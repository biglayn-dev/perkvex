import { AppSettings, MediaItem, WatchHistoryItem } from '../types';

const SETTINGS_KEY = 'flixstream_settings';
const WATCHLIST_KEY = 'flixstream_watchlist';
const HISTORY_KEY = 'flixstream_history';

export const DEFAULT_SETTINGS: AppSettings = {
  tmdbApiKey: 'abdde991ce2a56652d4c0ca156db7836', // Default TMDB key from flixstream
  ogadsLockerId: '4o7vvr',                         // Default OGAds Locker ID from flixstream
  ogadsEnabled: true,                              // 15-second hook active
  ogadsTimeoutSeconds: 15,                         // 15 seconds hook
  defaultServerId: '123embed',                     // Server 1 (123Embed Ultra HD) - Full movie, zero block
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    // Migrate any broken legacy server to 123embed
    if (
      !parsed.defaultServerId ||
      parsed.defaultServerId === 'cinema_stream' ||
      parsed.defaultServerId === 'native_html5' ||
      parsed.defaultServerId === 'vidsrc' ||
      parsed.defaultServerId === 'vidlink' ||
      parsed.defaultServerId === 'autoembed_co'
    ) {
      parsed.defaultServerId = '123embed';
    }
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function isMediaUnlocked(mediaId: number | string): boolean {
  try {
    return localStorage.getItem(`unlocked_${mediaId}`) === 'true';
  } catch {
    return false;
  }
}

export function setMediaUnlocked(mediaId: number | string, unlocked: boolean = true): void {
  try {
    if (unlocked) {
      localStorage.setItem(`unlocked_${mediaId}`, 'true');
    } else {
      localStorage.removeItem(`unlocked_${mediaId}`);
    }
  } catch (e) {
    console.error('Failed to update unlock status:', e);
  }
}

export function getWatchlist(): MediaItem[] {
  try {
    const raw = localStorage.getItem(WATCHLIST_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleWatchlist(item: MediaItem): boolean {
  try {
    const list = getWatchlist();
    const exists = list.some((m) => m.id === item.id);
    let updated: MediaItem[];
    if (exists) {
      updated = list.filter((m) => m.id !== item.id);
    } else {
      updated = [item, ...list];
    }
    localStorage.setItem(WATCHLIST_KEY, JSON.stringify(updated));
    return !exists;
  } catch {
    return false;
  }
}

export function isInWatchlist(id: number): boolean {
  const list = getWatchlist();
  return list.some((m) => m.id === id);
}

export function getWatchHistory(): WatchHistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addToWatchHistory(item: WatchHistoryItem): void {
  try {
    const history = getWatchHistory().filter((h) => h.id !== item.id);
    history.unshift(item);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 30)));
  } catch (e) {
    console.error('Failed to save watch history:', e);
  }
}
