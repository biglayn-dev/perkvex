import React, { useState, useEffect } from 'react';
import {
  Flame,
  Star,
  Film,
  Tv,
  Bookmark,
  Sparkles,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Search,
  ExternalLink,
  Shield,
  Layers,
} from 'lucide-react';
import { MediaItem, AppSettings, WatchHistoryItem } from './types';
import {
  fetchTrending,
  fetchTopRated,
  fetchPopular,
  fetchNowPlaying,
  fetchByGenre,
  searchMedia,
  createSlug,
  GENRE_MAP,
} from './services/tmdb';
import {
  loadSettings,
  saveSettings,
  getWatchlist,
  getWatchHistory,
} from './services/storage';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { MovieCard } from './components/MovieCard';
import { WatchCinema } from './components/WatchCinema';
import { SettingsModal } from './components/SettingsModal';
import { TrailerModal } from './components/TrailerModal';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Active View: 'browse' or 'watch'
  const [currentView, setCurrentView] = useState<'browse' | 'watch'>('browse');
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedGenre, setSelectedGenre] = useState<number | null>(null);

  // Watch State
  const [activeMediaId, setActiveMediaId] = useState<number | null>(null);
  const [activeMediaType, setActiveMediaType] = useState<'movie' | 'tv'>('movie');
  const [activeSlug, setActiveSlug] = useState<string>('');

  // Trailer Modal
  const [trailerMedia, setTrailerMedia] = useState<MediaItem | null>(null);
  const [isTrailerOpen, setIsTrailerOpen] = useState(false);

  // Movie Rows & Content
  const [heroMovie, setHeroMovie] = useState<MediaItem | null>(null);
  const [trendingMovies, setTrendingMovies] = useState<MediaItem[]>([]);
  const [topRatedMovies, setTopRatedMovies] = useState<MediaItem[]>([]);
  const [popularSeries, setPopularSeries] = useState<MediaItem[]>([]);
  const [nowPlaying, setNowPlaying] = useState<MediaItem[]>([]);
  const [genreMovies, setGenreMovies] = useState<MediaItem[]>([]);
  const [loadingGenre, setLoadingGenre] = useState(false);

  // Watchlist & History
  const [watchlist, setWatchlist] = useState<MediaItem[]>(getWatchlist);
  const [history, setHistory] = useState<WatchHistoryItem[]>(getWatchHistory);

  // Global search input query
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MediaItem[]>([]);

  // Check URL params on initial mount (supports watch.html?id=389&slug=12-angry-men or ?id=389)
  useEffect(() => {
    const handleUrlChange = () => {
      const params = new URLSearchParams(window.location.search);
      const idParam = params.get('id');
      const slugParam = params.get('slug') || '';
      const typeParam = (params.get('type') as 'movie' | 'tv') || 'movie';

      if (idParam) {
        const id = parseInt(idParam, 10);
        if (!isNaN(id)) {
          setActiveMediaId(id);
          setActiveSlug(slugParam);
          setActiveMediaType(typeParam);
          setCurrentView('watch');
          return;
        }
      }
      // If no id param, show browse
      setCurrentView('browse');
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  // Fetch initial catalog data from TMDB
  useEffect(() => {
    let isMounted = true;

    async function loadData() {
      try {
        const [trending, topRated, series, playing] = await Promise.all([
          fetchTrending('movie', 'day'),
          fetchTopRated('movie'),
          fetchTrending('tv', 'week'),
          fetchNowPlaying(),
        ]);

        if (!isMounted) return;

        if (trending && trending.length > 0) {
          setHeroMovie(trending[0]);
          setTrendingMovies(trending);
        }
        if (topRated) setTopRatedMovies(topRated);
        if (series) setPopularSeries(series);
        if (playing) setNowPlaying(playing);
      } catch (err) {
        console.error('Failed to load initial catalog:', err);
      }
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [settings.tmdbApiKey]);

  // Handle Genre Selection
  const handleSelectGenre = async (genreId: number | null) => {
    setSelectedGenre(genreId);
    if (!genreId) {
      setGenreMovies([]);
      return;
    }
    setLoadingGenre(true);
    const results = await fetchByGenre(genreId, currentTab === 'tv' ? 'tv' : 'movie');
    setGenreMovies(results);
    setLoadingGenre(false);
  };

  // Switch to Watch view
  const handleWatchMovie = (item: MediaItem) => {
    const mediaType = item.media_type || (currentTab === 'tv' ? 'tv' : 'movie');
    const slug = createSlug(item.title || item.name || 'stream');

    setActiveMediaId(item.id);
    setActiveMediaType(mediaType);
    setActiveSlug(slug);
    setCurrentView('watch');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Back from Watch view to Catalog
  const handleBackToBrowse = () => {
    const url = new URL(window.location.href);
    url.searchParams.delete('id');
    url.searchParams.delete('slug');
    url.searchParams.delete('type');
    url.searchParams.delete('s');
    url.searchParams.delete('e');
    window.history.pushState({}, '', url.toString());

    setCurrentView('browse');
    setWatchlist(getWatchlist());
    setHistory(getWatchHistory());
    document.title = 'FlixStream HD - Free Movies & TV Streaming';
  };

  // Open Trailer
  const handleOpenTrailer = (media: MediaItem) => {
    setTrailerMedia(media);
    setIsTrailerOpen(true);
  };

  // Watchlist count sync
  const refreshWatchlist = () => {
    setWatchlist(getWatchlist());
  };

  // Handle Nav Tab Change
  const handleTabChange = (tab: string) => {
    setCurrentTab(tab);
    setSelectedGenre(null);
    setGenreMovies([]);
    setSearchQuery('');
    setSearchResults([]);
    if (currentView === 'watch') {
      handleBackToBrowse();
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#141414] text-white flex flex-col font-sans selection:bg-[#e50914] selection:text-white">
      {/* Navbar */}
      <Navbar
        currentTab={currentTab}
        onTabChange={handleTabChange}
        onSelectMovie={handleWatchMovie}
        onOpenSettings={() => setIsSettingsOpen(true)}
        watchlistCount={watchlist.length}
      />

      {/* Main Content Area */}
      {currentView === 'watch' && activeMediaId ? (
        <main className="flex-1">
          <WatchCinema
            mediaId={activeMediaId}
            initialType={activeMediaType}
            slug={activeSlug}
            onBack={handleBackToBrowse}
            onSelectMovie={handleWatchMovie}
            onOpenTrailer={handleOpenTrailer}
          />
        </main>
      ) : (
        <main className="flex-1 pb-16">
          {/* Hero Banner (Only on Home / Movies / TV tab when not filtering by specific genre) */}
          {currentTab === 'home' && !selectedGenre && (
            <HeroBanner
              movie={heroMovie}
              onWatch={handleWatchMovie}
              onTrailer={handleOpenTrailer}
            />
          )}

          {/* Quick Notice Banner explaining FlixStream parity */}
          <div className="max-w-7xl mx-auto px-4 md:px-10 mt-6">
            <div className="p-3.5 bg-gradient-to-r from-red-950/60 via-neutral-900 to-neutral-900/80 rounded-xl border border-red-900/40 flex flex-wrap items-center justify-between gap-3 text-xs shadow-lg">
              <div className="flex items-center gap-2.5">
                <span className="p-1.5 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30">
                  <Flame className="w-4 h-4" />
                </span>
                <div>
                  <span className="font-bold text-white">FlixStream Engine Active:</span>{' '}
                  <span className="text-neutral-300">
                    TMDB v3 API + Multi-Server HD Mirrors (VidSrc, VidLink, AutoEmbed) + 15s OGAds Hook.
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    handleWatchMovie({
                      id: 389,
                      title: '12 Angry Men',
                      overview: 'Twelve jurors evaluate the evidence...',
                      poster_path: '/ow3wq89wM8qd5X7hWKxiRfsFf9C.jpg',
                      backdrop_path: '/qqHQsStV6exghCM7zbObuYBiYxw.jpg',
                      release_date: '1957-04-10',
                      vote_average: 8.5,
                      media_type: 'movie',
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold flex items-center gap-1.5 shadow-md shadow-red-700/30 transition-all hover:scale-105"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Stream 12 Angry Men (id=389)</span>
                </button>
                <button
                  onClick={() => setIsSettingsOpen(true)}
                  className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white border border-neutral-700 transition-colors"
                >
                  Config / Locker ID
                </button>
              </div>
            </div>
          </div>

          {/* Genres Chips Horizontal Scroll */}
          <div className="max-w-7xl mx-auto px-4 md:px-10 mt-6">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-xs font-bold text-neutral-400 flex items-center gap-1 pr-2">
                <SlidersHorizontal className="w-3.5 h-3.5 text-red-500" />
                <span>Genres:</span>
              </span>
              <button
                onClick={() => handleSelectGenre(null)}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedGenre === null
                    ? 'bg-red-600 text-white shadow-md shadow-red-600/40'
                    : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800'
                }`}
              >
                All Releases
              </button>
              {Object.entries(GENRE_MAP).map(([idStr, name]) => {
                const gid = Number(idStr);
                const isSelected = selectedGenre === gid;
                return (
                  <button
                    key={gid}
                    onClick={() => handleSelectGenre(gid)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                      isSelected
                        ? 'bg-red-600 text-white shadow-md shadow-red-600/40'
                        : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-800'
                    }`}
                  >
                    {name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filtered Genre Results (If a genre chip is selected) */}
          {selectedGenre && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-red-500" />
                  <span>{GENRE_MAP[selectedGenre]} Titles</span>
                </h2>
                <button
                  onClick={() => handleSelectGenre(null)}
                  className="text-xs text-red-400 hover:underline"
                >
                  Clear Filter
                </button>
              </div>

              {loadingGenre ? (
                <div className="py-12 text-center text-neutral-400 text-sm">
                  Loading {GENRE_MAP[selectedGenre]} movies...
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                  {genreMovies.map((movie) => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onSelect={handleWatchMovie}
                      onWatchlistChange={refreshWatchlist}
                    />
                  ))}
                </div>
              )}
            </section>
          )}

          {/* Watchlist Tab */}
          {currentTab === 'watchlist' && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-24">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2.5">
                  <Bookmark className="w-6 h-6 text-red-500" />
                  <h1 className="text-2xl font-black text-white">My Saved Watchlist</h1>
                </div>
                <span className="text-xs text-neutral-400">{watchlist.length} titles saved</span>
              </div>

              {watchlist.length === 0 ? (
                <div className="py-16 text-center text-neutral-400 space-y-3 bg-[#181818] rounded-2xl border border-neutral-800 p-8">
                  <Bookmark className="w-12 h-12 text-neutral-600 mx-auto" />
                  <h3 className="text-base font-bold text-white">Your watchlist is currently empty</h3>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                    Click the bookmark (+) button on any movie or TV series card to save it for streaming later.
                  </p>
                  <button
                    onClick={() => handleTabChange('home')}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors"
                  >
                    Browse Catalog
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                  {watchlist.map((item) => (
                    <MovieCard
                      key={item.id}
                      movie={item}
                      onSelect={handleWatchMovie}
                      onWatchlistChange={refreshWatchlist}
                    />
                  ))}
                </div>
              )}
            </section>
          )}

          {/* Default Rows (When not in specific standalone tab) */}
          {currentTab === 'home' && !selectedGenre && (
            <div className="max-w-7xl mx-auto px-4 md:px-10 mt-8 space-y-10">
              {/* Row 1: Trending This Week */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl md:text-2xl font-bold text-white flex items-center gap-2">
                    <span>Trending This Week</span>
                    <span className="text-red-500">🔥</span>
                  </h2>
                  <button
                    onClick={() => handleTabChange('trending')}
                    className="text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
                  >
                    View All →
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                  {trendingMovies.slice(0, 12).map((movie) => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onSelect={handleWatchMovie}
                      onWatchlistChange={refreshWatchlist}
                    />
                  ))}
                </div>
              </section>

              {/* Row 2: Top Rated & Recommended ⭐ */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl md:text-2xl font-bold text-white flex items-center gap-2">
                    <span>Top Rated & Recommended</span>
                    <span className="text-amber-400">⭐</span>
                  </h2>
                  <button
                    onClick={() => handleTabChange('top-rated')}
                    className="text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
                  >
                    View All →
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                  {topRatedMovies.slice(0, 12).map((movie) => (
                    <MovieCard
                      key={movie.id}
                      movie={movie}
                      onSelect={handleWatchMovie}
                      onWatchlistChange={refreshWatchlist}
                    />
                  ))}
                </div>
              </section>

              {/* Row 3: Popular TV Series 📺 */}
              <section>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl md:text-2xl font-bold text-white flex items-center gap-2">
                    <span>Popular TV Series</span>
                    <Tv className="w-5 h-5 text-blue-400" />
                  </h2>
                  <button
                    onClick={() => handleTabChange('tv')}
                    className="text-xs font-semibold text-neutral-400 hover:text-white transition-colors"
                  >
                    View All →
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                  {popularSeries.slice(0, 12).map((show) => (
                    <MovieCard
                      key={show.id}
                      movie={{ ...show, media_type: 'tv' }}
                      onSelect={handleWatchMovie}
                      onWatchlistChange={refreshWatchlist}
                    />
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* Standalone Movies Tab */}
          {currentTab === 'movies' && !selectedGenre && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-24">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2.5">
                  <Film className="w-6 h-6 text-red-500" />
                  <h1 className="text-2xl font-black text-white">Full HD Cinema Movies</h1>
                </div>
                <span className="text-xs text-neutral-400">Multi-Server CDN Embeds</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                {[...trendingMovies, ...topRatedMovies].map((movie) => (
                  <MovieCard
                    key={`m-${movie.id}`}
                    movie={{ ...movie, media_type: 'movie' }}
                    onSelect={handleWatchMovie}
                    onWatchlistChange={refreshWatchlist}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Standalone TV Series Tab */}
          {currentTab === 'tv' && !selectedGenre && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-24">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2.5">
                  <Tv className="w-6 h-6 text-blue-500" />
                  <h1 className="text-2xl font-black text-white">TV Shows & Series</h1>
                </div>
                <span className="text-xs text-neutral-400">Seasons & Episodes Auto-Loaded</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                {popularSeries.map((show) => (
                  <MovieCard
                    key={`tv-${show.id}`}
                    movie={{ ...show, media_type: 'tv' }}
                    onSelect={handleWatchMovie}
                    onWatchlistChange={refreshWatchlist}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Standalone Trending Tab */}
          {currentTab === 'trending' && !selectedGenre && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-24">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2.5">
                  <Flame className="w-6 h-6 text-red-500" />
                  <h1 className="text-2xl font-black text-white">Trending Releases</h1>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                {trendingMovies.map((movie) => (
                  <MovieCard
                    key={`tr-${movie.id}`}
                    movie={movie}
                    onSelect={handleWatchMovie}
                    onWatchlistChange={refreshWatchlist}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Standalone Top Rated Tab */}
          {currentTab === 'top-rated' && !selectedGenre && (
            <section className="max-w-7xl mx-auto px-4 md:px-10 mt-24">
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-neutral-800">
                <div className="flex items-center gap-2.5">
                  <Star className="w-6 h-6 text-amber-400" />
                  <h1 className="text-2xl font-black text-white">All-Time Top Rated Classics</h1>
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
                {topRatedMovies.map((movie) => (
                  <MovieCard
                    key={`top-${movie.id}`}
                    movie={movie}
                    onSelect={handleWatchMovie}
                    onWatchlistChange={refreshWatchlist}
                  />
                ))}
              </div>
            </section>
          )}
        </main>
      )}

      {/* Footer (Matching FlixStream Footer) */}
      <footer className="mt-auto border-t border-neutral-800/80 bg-[#0e0e0e] py-10 px-4 text-center text-xs text-neutral-400">
        <div className="max-w-4xl mx-auto space-y-3">
          <div className="flex items-center justify-center gap-1 text-lg font-black tracking-wider text-[#e50914]">
            FLIX<span className="text-white">STREAM</span>
          </div>
          <p className="text-neutral-400">
            &copy; 2026 FlixStream HD. High Performance Cinema Catalog & Stream Aggregator.
          </p>
          <p className="text-[11px] text-neutral-400 max-w-xl mx-auto leading-relaxed">
            This platform indexes metadata via TMDB (The Movie Database) API and embeds third-party CDN streaming servers (VidSrc, VidLink, AutoEmbed). No video media files are hosted on this server.
          </p>
          <div className="pt-2 flex items-center justify-center gap-4 text-neutral-400 text-xs">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="hover:text-white transition-colors underline"
            >
              Locker & TMDB Settings
            </button>
            <span>•</span>
            <button
              onClick={() => handleTabChange('home')}
              className="hover:text-white transition-colors underline"
            >
              Browse Catalog
            </button>
            <span>•</span>
            <button
              onClick={() => {
                handleWatchMovie({
                  id: 389,
                  title: '12 Angry Men',
                  overview: 'Twelve jurors evaluate the evidence...',
                  poster_path: '/ow3wq89wM8qd5X7hWKxiRfsFf9C.jpg',
                  backdrop_path: '/qqHQsStV6exghCM7zbObuYBiYxw.jpg',
                  release_date: '1957-04-10',
                  vote_average: 8.5,
                  media_type: 'movie',
                });
              }}
              className="hover:text-white transition-colors underline text-red-400"
            >
              12 Angry Men (id=389)
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <SettingsModal
        settings={settings}
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onSave={(newSet) => setSettings(newSet)}
      />

      <TrailerModal
        media={trailerMedia}
        isOpen={isTrailerOpen}
        onClose={() => setIsTrailerOpen(false)}
      />
    </div>
  );
}
