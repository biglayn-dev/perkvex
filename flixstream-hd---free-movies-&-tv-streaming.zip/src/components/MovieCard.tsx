import React from 'react';
import { Play, Plus, Check, Star } from 'lucide-react';
import { MediaItem } from '../types';
import { TMDB_IMAGE_W500, createSlug } from '../services/tmdb';
import { isInWatchlist, toggleWatchlist } from '../services/storage';

interface MovieCardProps {
  movie: MediaItem;
  onSelect: (item: MediaItem) => void;
  onWatchlistChange?: () => void;
}

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onSelect, onWatchlistChange }) => {
  const [inList, setInList] = React.useState(() => isInWatchlist(movie.id));

  const title = movie.title || movie.name || 'Untitled';
  const year = (movie.release_date || movie.first_air_date || '').split('-')[0] || 'HD';
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A';
  const posterUrl = movie.poster_path
    ? `${TMDB_IMAGE_W500}${movie.poster_path}`
    : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=500&auto=format&fit=crop&q=80';

  const handleToggleWatchlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    const added = toggleWatchlist(movie);
    setInList(added);
    if (onWatchlistChange) onWatchlistChange();
  };

  return (
    <div
      onClick={() => onSelect(movie)}
      className="group relative flex flex-col rounded-lg overflow-hidden bg-[#1e1e1e] cursor-pointer transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl hover:shadow-red-950/40 hover:border-red-600/40 border border-neutral-800/80"
    >
      {/* Poster Image */}
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-[#181818]">
        <img
          src={posterUrl}
          alt={title}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Quality Badge */}
        <div className="absolute top-2 left-2 z-10">
          <span className="bg-black/75 backdrop-blur-md text-[10px] font-bold uppercase tracking-wider text-amber-400 px-2 py-0.5 rounded border border-amber-500/30">
            {movie.media_type === 'tv' ? 'SERIES' : '1080P'}
          </span>
        </div>

        {/* Watchlist Quick Button */}
        <button
          onClick={handleToggleWatchlist}
          title={inList ? 'Remove from Watchlist' : 'Add to Watchlist'}
          className="absolute top-2 right-2 z-10 w-8 h-8 rounded-full bg-black/70 backdrop-blur-md border border-neutral-700 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all hover:bg-red-600 hover:border-red-600 hover:scale-110"
        >
          {inList ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
        </button>

        {/* Hover Action Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-10 h-10 rounded-full bg-[#e50914] text-white flex items-center justify-center shadow-lg shadow-red-600/50 transform group-hover:scale-105 transition-transform">
              <Play className="w-5 h-5 fill-white ml-0.5" />
            </span>
            <span className="text-xs font-bold text-white tracking-wide">STREAM NOW</span>
          </div>
          <p className="text-[11px] text-neutral-300 line-clamp-2 leading-relaxed">
            {movie.overview || 'Click to watch in high definition with multi-server mirrors.'}
          </p>
        </div>
      </div>

      {/* Card Info */}
      <div className="p-2.5 flex flex-col justify-between flex-1 bg-gradient-to-b from-[#1c1c1c] to-[#141414]">
        <h3 className="font-semibold text-sm text-neutral-100 truncate group-hover:text-red-400 transition-colors" title={title}>
          {title}
        </h3>

        <div className="flex items-center justify-between text-xs text-neutral-400 mt-1.5 pt-1 border-t border-neutral-800/60">
          <div className="flex items-center gap-1 text-emerald-400 font-semibold">
            <Star className="w-3 h-3 fill-emerald-400" />
            <span>{rating}</span>
          </div>
          <span>{year}</span>
          <span className="bg-neutral-800 text-[10px] font-bold text-neutral-300 px-1.5 py-0.5 rounded">
            HD
          </span>
        </div>
      </div>
    </div>
  );
};
