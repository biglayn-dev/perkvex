import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Play,
  RotateCw,
  Maximize2,
  Moon,
  Sun,
  Share2,
  Bookmark,
  Check,
  Film,
  Sparkles,
  Lock,
  Unlock,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  Tv,
  ListVideo,
  Clapperboard,
  X
} from 'lucide-react';
import { MediaItem, TVSeason, TVEpisode } from '../types';
import { STREAM_SERVERS, getStreamUrl } from '../services/servers';
import {
  fetchMediaDetails,
  fetchTVSeason,
  createSlug,
  TMDB_IMAGE_ORIGINAL,
  TMDB_IMAGE_W500,
} from '../services/tmdb';
import {
  loadSettings,
  isMediaUnlocked,
  setMediaUnlocked,
  isInWatchlist,
  toggleWatchlist,
  addToWatchHistory,
} from '../services/storage';
import { MovieCard } from './MovieCard';

interface WatchCinemaProps {
  mediaId: number;
  initialType?: 'movie' | 'tv';
  slug?: string;
  onBack: () => void;
  onSelectMovie: (item: MediaItem) => void;
  onOpenTrailer?: (media: MediaItem) => void;
}

export const WatchCinema: React.FC<WatchCinemaProps> = ({
  mediaId,
  initialType = 'movie',
  slug: initialSlug,
  onBack,
  onSelectMovie,
  onOpenTrailer,
}) => {
  const settings = loadSettings();
  const [media, setMedia] = useState<MediaItem | null>(null);
  const [loading, setLoading] = useState(true);
  const initialServer = settings.defaultServerId || '123embed';
  const [activeServer, setActiveServer] = useState(initialServer);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isUnlocked, setIsUnlockedState] = useState(() => isMediaUnlocked(mediaId));
  const [showLockerModal, setShowLockerModal] = useState(false);
  const [lockerCountdown, setLockerCountdown] = useState<number | null>(null);
  const [theaterMode, setTheaterMode] = useState(false);
  const [lightsOff, setLightsOff] = useState(false);
  const [inWatchlist, setInWatchlist] = useState(() => isInWatchlist(mediaId));
  const [copiedLink, setCopiedLink] = useState(false);

  // TV Series Season & Episode
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [selectedEpisode, setSelectedEpisode] = useState(1);
  const [seasonData, setSeasonData] = useState<TVSeason | null>(null);
  const [loadingSeason, setLoadingSeason] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const mediaType = media?.media_type || initialType;
  const title = media?.title || media?.name || 'Watch Stream HD';
  const slug = initialSlug || createSlug(title);

  // Update browser URL query to match flixstream watch.html?id=389&slug=12-angry-men
  useEffect(() => {
    const url = new URL(window.location.href);
    url.searchParams.set('id', String(mediaId));
    url.searchParams.set('slug', slug);
    if (mediaType === 'tv') {
      url.searchParams.set('type', 'tv');
      url.searchParams.set('s', String(selectedSeason));
      url.searchParams.set('e', String(selectedEpisode));
    } else {
      url.searchParams.delete('type');
      url.searchParams.delete('s');
      url.searchParams.delete('e');
    }
    window.history.replaceState({}, '', url.toString());
  }, [mediaId, slug, mediaType, selectedSeason, selectedEpisode]);

  // Fetch Media Details
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setIsPlaying(false);
    setShowLockerModal(false);
    setIsUnlockedState(isMediaUnlocked(mediaId));

    if (timerRef.current) clearTimeout(timerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);

    fetchMediaDetails(mediaId, initialType).then((data) => {
      if (!isMounted) return;
      if (data) {
        setMedia(data);
        document.title = `Watch ${data.title || data.name} (1080p HD) - FlixStream`;
        addToWatchHistory({
          id: data.id,
          title: data.title || data.name || 'Movie',
          poster_path: data.poster_path,
          media_type: data.media_type || initialType,
          slug: createSlug(data.title || data.name || 'movie'),
          season: selectedSeason,
          episode: selectedEpisode,
          timestamp: Date.now(),
        });
      }
      setLoading(false);
    });

    return () => {
      isMounted = false;
      if (timerRef.current) clearTimeout(timerRef.current);
      if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
    };
  }, [mediaId, initialType]);

  // Fetch Season episodes if TV
  useEffect(() => {
    if (mediaType === 'tv' && mediaId) {
      setLoadingSeason(true);
      fetchTVSeason(mediaId, selectedSeason).then((data) => {
        setSeasonData(data);
        setLoadingSeason(false);
      });
    }
  }, [mediaId, mediaType, selectedSeason]);

  // The 15-second Hook & Lock mechanism matching flixstream player.js
  const handleStartStreaming = () => {
    setIsPlaying(true);

    // If already unlocked or locker disabled, don't trigger modal
    if (isUnlocked || !settings.ogadsEnabled) {
      return;
    }

    const timeoutSec = settings.ogadsTimeoutSeconds || 15;
    setLockerCountdown(timeoutSec);

    // Countdown interval
    countdownIntervalRef.current = setInterval(() => {
      setLockerCountdown((prev) => {
        if (prev === null || prev <= 1) {
          if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    // Main 15s timeout
    timerRef.current = setTimeout(() => {
      if (!isMediaUnlocked(mediaId)) {
        setShowLockerModal(true);
      }
    }, timeoutSec * 1000);
  };

  const handleUnlockStream = () => {
    setIsUnlockedState(true);
    setMediaUnlocked(mediaId, true);
    setShowLockerModal(false);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (countdownIntervalRef.current) clearInterval(countdownIntervalRef.current);
  };

  const handleToggleWatchlist = () => {
    if (!media) return;
    const added = toggleWatchlist(media);
    setInWatchlist(added);
  };

  const handleCopyLink = () => {
    const fullUrl = window.location.href;
    navigator.clipboard.writeText(fullUrl).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    });
  };

  const handleReloadPlayer = () => {
    if (iframeRef.current) {
      const currentSrc = iframeRef.current.src;
      iframeRef.current.src = '';
      setTimeout(() => {
        if (iframeRef.current) iframeRef.current.src = currentSrc;
      }, 100);
    }
  };

  // Full Movie Embed URL for current server
  const currentStreamUrl = getStreamUrl(
    activeServer,
    mediaType,
    mediaId,
    selectedSeason,
    selectedEpisode
  );

  // Dynamic OGAds Locker URL with SubIDs
  const dynamicOgadsUrl = `https://appcomplete.org/cl/i/${settings.ogadsLockerId || '4o7vvr'}?aff_sub=${encodeURIComponent(
    slug
  )}&aff_sub2=${encodeURIComponent(String(mediaId))}`;

  const rating = media?.vote_average ? media.vote_average.toFixed(1) : '8.5';
  const year = (media?.release_date || media?.first_air_date || '').split('-')[0] || '1957';
  const runtime = media?.runtime ? `${media.runtime} min` : '100 min';

  return (
    <div
      className={`min-h-screen transition-colors duration-500 pb-20 ${
        lightsOff ? 'bg-[#050505]' : 'bg-[#0f0f0f]'
      }`}
    >
      {/* Ambient Backdrop Glow */}
      {media?.backdrop_path && !lightsOff && (
        <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
          <img
            src={`${TMDB_IMAGE_ORIGINAL}${media.backdrop_path}`}
            alt=""
            className="w-full h-full object-cover blur-3xl scale-125 transform"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/80 to-transparent" />
        </div>
      )}

      {/* Watch Page Top Navigation Bar */}
      <div className="relative z-40 bg-[#141414]/90 backdrop-blur-md border-b border-neutral-800/80 sticky top-0 px-4 md:px-8 py-3.5 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm font-semibold text-neutral-300 hover:text-white transition-colors bg-neutral-900/80 hover:bg-neutral-800 px-3 py-1.5 rounded-lg border border-neutral-800"
        >
          <ArrowLeft className="w-4 h-4 text-red-500" />
          <span>Back to Catalog</span>
        </button>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-neutral-400 bg-neutral-900/60 px-3 py-1.5 rounded-md border border-neutral-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>CDN Mirror: {activeServer.toUpperCase()}</span>
          </div>

          <button
            onClick={() => setLightsOff(!lightsOff)}
            title={lightsOff ? 'Lights On' : 'Lights Off'}
            className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors"
          >
            {lightsOff ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={handleCopyLink}
            title="Share Watch Link"
            className="flex items-center gap-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 px-3 py-1.5 rounded-lg transition-colors"
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4" />
                <span className="hidden sm:inline">Share</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Cinema Theater Container */}
      <div
        className={`relative z-10 mx-auto px-4 pt-6 transition-all duration-300 ${
          theaterMode ? 'max-w-[1440px]' : 'max-w-5xl'
        }`}
      >
        {/* Breadcrumb / Title header */}
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs md:text-sm text-neutral-400">
            <span className="text-red-500 font-bold uppercase tracking-wider">
              {mediaType === 'tv' ? 'TV Series' : 'Cinema Movie'}
            </span>
            <span>•</span>
            <span className="text-white font-medium truncate max-w-xs md:max-w-md">{title}</span>
            {mediaType === 'tv' && (
              <span className="bg-red-950/80 text-red-300 border border-red-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
                S{selectedSeason} E{selectedEpisode}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {media?.videos?.results && media.videos.results.length > 0 && onOpenTrailer && (
              <button
                onClick={() => onOpenTrailer(media)}
                className="flex items-center gap-1 text-xs text-neutral-300 hover:text-white bg-neutral-900/90 border border-neutral-800 hover:border-neutral-700 px-2.5 py-1 rounded transition-colors"
              >
                <Clapperboard className="w-3.5 h-3.5 text-red-400" />
                <span>Trailer</span>
              </button>
            )}

            <button
              onClick={() => setTheaterMode(!theaterMode)}
              className="hidden md:flex items-center gap-1 text-xs text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 px-2.5 py-1 rounded"
              title="Toggle Theater Mode"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>{theaterMode ? 'Default' : 'Theater'}</span>
            </button>

            <button
              onClick={handleReloadPlayer}
              className="flex items-center gap-1 text-xs text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 px-2.5 py-1 rounded transition-colors"
              title="Reload Stream Player"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Reload Stream</span>
            </button>

            <a
              href={currentStreamUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 px-2.5 py-1 rounded transition-colors"
              title="Open full length movie in dedicated popout window"
            >
              <ExternalLink className="w-3.5 h-3.5 text-red-500" />
              <span>Direct Tab ↗</span>
            </a>
          </div>
        </div>

        {/* 16:9 Video Player Wrapper */}
        <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-neutral-800 shadow-2xl shadow-black cinema-glow">
          {/* Real Full Movie Embed Engine */}
          {isPlaying && (
            <iframe
              ref={iframeRef}
              key={`fullmovie-${activeServer}-${mediaType}-${mediaId}-${selectedSeason}-${selectedEpisode}`}
              src={currentStreamUrl}
              title={`${title} Full Movie Stream`}
              className="w-full h-full border-0 absolute inset-0 bg-black"
              referrerPolicy="origin"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
              allowFullScreen
            />
          )}

          {/* Big Play Overlay (Matches FlixStream play-trigger-overlay) */}
          {!isPlaying && (
            <div
              onClick={handleStartStreaming}
              className="absolute inset-0 z-20 bg-gradient-to-t from-black/95 via-black/80 to-black/60 backdrop-blur-sm flex flex-col items-center justify-center cursor-pointer group transition-all duration-300"
            >
              <div className="relative mb-4">
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-[#e50914] text-white flex items-center justify-center shadow-2xl shadow-red-600/70 group-hover:scale-110 transition-transform duration-300 ring-8 ring-red-600/20">
                  <Play className="w-10 h-10 md:w-12 md:h-12 fill-white ml-1.5" />
                </div>
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
                </span>
              </div>

              <h2 className="text-xl md:text-3xl font-black text-white tracking-wide text-center px-4 mb-2 drop-shadow-md">
                Start Full Movie in 1080p Full HD
              </h2>
              <p className="text-xs md:text-sm text-neutral-300 font-medium text-center px-4 max-w-lg mb-4">
                100% Full Length Film • Multi-Subtitles • Dolby Audio • No Cuts
              </p>

              <div className="flex items-center gap-2 bg-neutral-900/90 border border-neutral-700/80 px-4 py-1.5 rounded-full text-xs text-neutral-300 font-semibold shadow-inner">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Active Server: {STREAM_SERVERS.find((s) => s.id === activeServer)?.name || activeServer}</span>
              </div>
            </div>
          )}

          {/* Locker Countdown Badge (Subtle top right indicator during 15s) */}
          {isPlaying && !isUnlocked && settings.ogadsEnabled && lockerCountdown !== null && (
            <div className="absolute top-3 right-3 z-30 bg-black/85 backdrop-blur-md border border-red-500/40 px-3 py-1 rounded-full text-[11px] font-semibold text-neutral-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>HD Stream Buffering ({lockerCountdown}s)</span>
            </div>
          )}

          {/* OGAds Clean Locker Modal (Ghay-tla3 f 15s) */}
          {showLockerModal && (
            <div className="absolute inset-0 z-40 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-300">
              <div className="w-full max-w-md bg-[#181818] border border-red-600/40 rounded-2xl shadow-2xl p-5 relative overflow-hidden flex flex-col max-h-[92%]">
                {/* Header */}
                <div className="flex items-start justify-between pb-3 border-b border-neutral-800">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30">
                      <Lock className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm md:text-base text-white">
                        HD Stream Verification
                      </h3>
                      <p className="text-[11px] text-neutral-400">
                        Unlock 1080p high-bandwidth stream
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={handleUnlockStream}
                    className="text-neutral-400 hover:text-white p-1 hover:bg-neutral-800 rounded-lg transition-colors"
                    title="Bypass / Unlock"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* SubIDs & Darija / English Helper */}
                <div className="mt-3 p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 space-y-1">
                  <div className="flex items-center justify-between text-neutral-400">
                    <span>Locker ID: {settings.ogadsLockerId || '4o7vvr'}</span>
                    <span className="text-emerald-400 font-mono text-[10px]">
                      Tracking: {slug}
                    </span>
                  </div>
                  <p className="text-neutral-300 text-[11px] leading-tight">
                    🇲🇦 <em>Had l-locker kay-tla3 f 15s b tari9a d flixstream.</em> Complete 1 quick
                    sponsor offer to unlock uninterrupted streaming!
                  </p>
                </div>

                {/* OGAds Embed Frame */}
                <div className="my-3 flex-1 min-h-[220px] rounded-xl overflow-hidden bg-black border border-neutral-800 relative">
                  <iframe
                    src={dynamicOgadsUrl}
                    title="Verification Offers"
                    className="w-full h-full border-0 absolute inset-0"
                  />
                </div>

                {/* Bottom Unlock / Bypass actions */}
                <div className="pt-2 flex items-center justify-between gap-2">
                  <button
                    onClick={handleUnlockStream}
                    className="flex-1 py-2.5 px-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs rounded-xl shadow-lg shadow-red-700/30 flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>Unlock Stream Now (Test / Complete)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Server Switcher Bar (Exact match to flixstream servers-bar) */}
        <div className="mt-4 p-3 bg-[#181818] rounded-xl border border-neutral-800/80 flex flex-wrap items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5 mr-1">
              <Film className="w-4 h-4 text-red-500" />
              <span>Switch Server:</span>
            </span>

            {STREAM_SERVERS.map((srv) => {
              const isActive = activeServer === srv.id;
              return (
                <button
                  key={srv.id}
                  onClick={() => {
                    setActiveServer(srv.id);
                    setIsPlaying(true);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-[#e50914] text-white shadow-lg shadow-red-600/40 ring-2 ring-red-400/30'
                      : 'bg-neutral-850 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-750'
                  }`}
                >
                  <span>{srv.name}</span>
                  <span
                    className={`text-[9px] px-1 py-0.2 rounded uppercase font-semibold ${
                      isActive ? 'bg-black/30 text-white' : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    {srv.badge}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick status pill */}
          <div className="flex items-center gap-2 text-xs">
            {isUnlocked ? (
              <span className="flex items-center gap-1 text-emerald-400 font-semibold bg-emerald-950/40 border border-emerald-800/50 px-2.5 py-1 rounded-full">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Unlocked HD</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-amber-400 font-semibold bg-amber-950/40 border border-amber-800/50 px-2.5 py-1 rounded-full">
                <Lock className="w-3.5 h-3.5" />
                <span>15s Hook Active</span>
              </span>
            )}
          </div>
        </div>

        {/* Quick Troubleshoot Bar */}
        <div className="mt-2.5 px-3 py-2 bg-neutral-900/60 rounded-lg border border-neutral-800/60 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>
              All 6 servers provide the <strong>100% Complete Full Movie (1080p HD)</strong>. If a mirror buffers, switch to <strong>Server 1 (123Embed)</strong> or <strong>Server 2 (AnyEmbed)</strong>.
            </span>
          </div>
          <a
            href={currentStreamUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1 hover:underline transition-colors shrink-0"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Open in Direct Window ↗</span>
          </a>
        </div>

        {/* TV Series Season & Episode Picker (if media_type === 'tv') */}
        {mediaType === 'tv' && (
          <div className="mt-4 p-4 bg-[#181818] rounded-xl border border-neutral-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Tv className="w-5 h-5 text-red-500" />
                <h3 className="font-bold text-sm text-white">Episodes & Seasons</h3>
              </div>

              {/* Season Selector */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-neutral-400">Season:</span>
                <select
                  value={selectedSeason}
                  onChange={(e) => {
                    setSelectedSeason(Number(e.target.value));
                    setSelectedEpisode(1);
                  }}
                  className="bg-neutral-900 border border-neutral-700 text-white text-xs font-semibold rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500"
                >
                  {Array.from(
                    { length: media?.number_of_seasons || 1 },
                    (_, i) => i + 1
                  ).map((s) => (
                    <option key={s} value={s}>
                      Season {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Episode Grid / Selector */}
            {loadingSeason ? (
              <div className="py-6 text-center text-xs text-neutral-400">
                Loading Season {selectedSeason} episodes...
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-56 overflow-y-auto pr-1">
                {(seasonData?.episodes || []).map((ep) => {
                  const isCur = selectedEpisode === ep.episode_number;
                  return (
                    <button
                      key={ep.id}
                      onClick={() => {
                        setSelectedEpisode(ep.episode_number);
                        setIsPlaying(true);
                      }}
                      className={`p-2 rounded-lg text-left transition-all border ${
                        isCur
                          ? 'bg-red-600/20 border-red-500 text-white font-bold ring-1 ring-red-500'
                          : 'bg-neutral-900/80 hover:bg-neutral-850 border-neutral-800 text-neutral-300'
                      }`}
                    >
                      <div className="text-[10px] text-neutral-400 font-mono">
                        EP {ep.episode_number}
                      </div>
                      <div className="text-xs truncate font-medium mt-0.5">
                        {ep.name || `Episode ${ep.episode_number}`}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Movie Details Card (Exact match to flixstream movie-details-card) */}
        <div className="mt-6 bg-[#181818] rounded-2xl border border-neutral-800/80 p-5 md:p-7 shadow-xl">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            {/* Poster */}
            <div className="w-32 md:w-44 flex-shrink-0 mx-auto md:mx-0">
              <div className="aspect-[2/3] rounded-xl overflow-hidden shadow-2xl border border-neutral-700/60 bg-neutral-900">
                <img
                  src={
                    media?.poster_path
                      ? `${TMDB_IMAGE_W500}${media.poster_path}`
                      : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=500&auto=format&fit=crop&q=80'
                  }
                  alt={title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Details Right */}
            <div className="flex-1 space-y-3.5 text-left">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h1 className="text-2xl md:text-3xl font-black text-white leading-tight">
                    {title}
                  </h1>
                  {media?.tagline && (
                    <p className="text-xs text-neutral-400 italic mt-0.5">"{media.tagline}"</p>
                  )}
                </div>

                <button
                  onClick={handleToggleWatchlist}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    inWatchlist
                      ? 'bg-red-600/20 border-red-500 text-red-400'
                      : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-700 text-neutral-200'
                  }`}
                >
                  {inWatchlist ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                  <span>{inWatchlist ? 'In Watchlist' : 'Add to Watchlist'}</span>
                </button>
              </div>

              {/* Meta Tags */}
              <div className="flex flex-wrap items-center gap-2.5 text-xs">
                <span className="font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                  ★ {rating} TMDB
                </span>
                <span className="text-neutral-300 font-semibold">{year}</span>
                <span className="text-neutral-400">{runtime}</span>
                <span className="bg-neutral-800 text-neutral-300 font-bold px-2 py-0.5 rounded text-[10px] tracking-wider border border-neutral-700">
                  1080P FULL HD
                </span>
                <span className="bg-red-950/70 text-red-300 font-bold px-2 py-0.5 rounded text-[10px] tracking-wider border border-red-800/60">
                  DOLBY 5.1
                </span>
              </div>

              {/* Genres List */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(media?.genres || []).map((g) => (
                  <span
                    key={g.id}
                    className="bg-neutral-850 hover:bg-neutral-800 text-neutral-300 border border-neutral-750 text-xs px-2.5 py-1 rounded-md font-medium transition-colors"
                  >
                    {g.name}
                  </span>
                ))}
              </div>

              {/* Synopsis / Overview */}
              <div>
                <h4 className="text-xs uppercase tracking-wider text-neutral-400 font-bold mb-1">
                  Synopsis
                </h4>
                <p className="text-neutral-300 text-sm leading-relaxed">
                  {media?.overview || 'No synopsis provided for this title.'}
                </p>
              </div>

              {/* Cast & Crew preview */}
              {media?.credits?.cast && media.credits.cast.length > 0 && (
                <div className="pt-2">
                  <h4 className="text-xs uppercase tracking-wider text-neutral-400 font-bold mb-2">
                    Starring Cast
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {media.credits.cast.slice(0, 6).map((actor) => (
                      <div
                        key={actor.id}
                        className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 px-2.5 py-1 rounded-lg"
                      >
                        {actor.profile_path && (
                          <img
                            src={`${TMDB_IMAGE_W500}${actor.profile_path}`}
                            alt={actor.name}
                            className="w-5 h-5 rounded-full object-cover"
                          />
                        )}
                        <div className="text-left">
                          <div className="text-xs font-semibold text-neutral-200">{actor.name}</div>
                          <div className="text-[10px] text-neutral-400">{actor.character}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Similar / Recommended Titles */}
        {media?.similar?.results && media.similar.results.length > 0 && (
          <div className="mt-10">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-red-500" />
              <h2 className="text-lg md:text-xl font-bold text-white">Recommended For You</h2>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
              {media.similar.results.slice(0, 6).map((sim) => (
                <MovieCard
                  key={sim.id}
                  movie={{ ...sim, media_type: mediaType }}
                  onSelect={onSelectMovie}
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
