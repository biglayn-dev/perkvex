import React, { useState } from 'react';
import {
  X,
  Key,
  Shield,
  Layers,
  Clock,
  RotateCcw,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  Server,
  Zap,
  Download,
  Terminal,
  Laptop,
  FolderDown,
} from 'lucide-react';
import { AppSettings } from '../types';
import { DEFAULT_SETTINGS, saveSettings } from '../services/storage';
import { STREAM_SERVERS } from '../services/servers';

interface SettingsModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onSave: (newSettings: AppSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isOpen,
  onClose,
  onSave,
}) => {
  const [formData, setFormData] = useState<AppSettings>(settings);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'config' | 'how-it-works' | 'download-pc'>('config');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveSettings(formData);
    onSave(formData);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  const handleReset = () => {
    setFormData(DEFAULT_SETTINGS);
    saveSettings(DEFAULT_SETTINGS);
    onSave(DEFAULT_SETTINGS);
  };

  const handleClearUnlocks = () => {
    // Clear all unlocked_* keys from localStorage
    Object.keys(localStorage).forEach((k) => {
      if (k.startsWith('unlocked_')) localStorage.removeItem(k);
    });
    alert('All media unlock states reset! The 15s locker will trigger again for testing.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#181818] border border-neutral-700/80 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base md:text-lg font-bold text-white">
                FlixStream Architecture & Settings
              </h2>
              <p className="text-xs text-neutral-400">
                TMDB API, OGAds Locker Hook & Server Configuration
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-5 pt-3 pb-2 flex gap-3 border-b border-neutral-800 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('config')}
            className={`pb-2 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'config'
                ? 'border-red-600 text-white font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            ⚙️ Configuration
          </button>
          <button
            onClick={() => setActiveTab('download-pc')}
            className={`pb-2 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'download-pc'
                ? 'border-red-600 text-white font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <FolderDown className="w-3.5 h-3.5 text-red-500" />
            <span>💻 Télécharger sur PC (ZIP)</span>
          </button>
          <button
            onClick={() => setActiveTab('how-it-works')}
            className={`pb-2 border-b-2 transition-colors flex items-center gap-1 whitespace-nowrap ${
              activeTab === 'how-it-works'
                ? 'border-red-600 text-white font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Architecture (FlixStream)</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-5 text-left text-xs">
          {activeTab === 'config' ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* TMDB API Key */}
              <div>
                <label className="block text-neutral-200 font-bold mb-1.5 flex items-center gap-1.5">
                  <Key className="w-4 h-4 text-red-500" />
                  <span>TMDB API Key (v3 auth)</span>
                </label>
                <input
                  type="text"
                  value={formData.tmdbApiKey}
                  onChange={(e) => setFormData({ ...formData, tmdbApiKey: e.target.value })}
                  placeholder="e.g. abdde991ce2a56652d4c0ca156db7836"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
                />
                <p className="text-[11px] text-neutral-400 mt-1">
                  Default key is active. Replace with your own key from themoviedb.org anytime.
                </p>
              </div>

              {/* OGAds Locker ID */}
              <div>
                <label className="block text-neutral-200 font-bold mb-1.5 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-amber-500" />
                  <span>OGAds CPA Locker ID</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={formData.ogadsLockerId}
                    onChange={(e) => setFormData({ ...formData, ogadsLockerId: e.target.value })}
                    placeholder="e.g. 4o7vvr"
                    className="flex-1 bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-red-500"
                  />
                  <span className="bg-neutral-800 text-neutral-300 border border-neutral-700 px-3 py-2 rounded-lg font-mono text-[11px] flex items-center">
                    appcomplete.org/cl/i/...
                  </span>
                </div>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Reference flixstream used ID: <code className="text-red-400">4o7vvr</code> with SubID tracking.
                </p>
              </div>

              {/* Toggle Locker */}
              <div className="p-3 bg-neutral-900/90 rounded-xl border border-neutral-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs">Enable 15s Locker Hook</div>
                  <div className="text-[11px] text-neutral-400">
                    Triggers offer modal after stream starts
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.ogadsEnabled}
                    onChange={(e) => setFormData({ ...formData, ogadsEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-600"></div>
                </label>
              </div>

              {/* Locker Timeout */}
              {formData.ogadsEnabled && (
                <div>
                  <label className="block text-neutral-200 font-bold mb-1.5 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-emerald-500" />
                    <span>Locker Trigger Timer (Seconds)</span>
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[5, 10, 15, 30].map((sec) => (
                      <button
                        type="button"
                        key={sec}
                        onClick={() => setFormData({ ...formData, ogadsTimeoutSeconds: sec })}
                        className={`py-2 rounded-lg font-bold border transition-all ${
                          formData.ogadsTimeoutSeconds === sec
                            ? 'bg-red-600 border-red-500 text-white'
                            : 'bg-neutral-900 border-neutral-750 text-neutral-300 hover:bg-neutral-800'
                        }`}
                      >
                        {sec}s {sec === 15 && '(Flix)'}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Default Server */}
              <div>
                <label className="block text-neutral-200 font-bold mb-1.5 flex items-center gap-1.5">
                  <Server className="w-4 h-4 text-blue-500" />
                  <span>Default Streaming Server</span>
                </label>
                <select
                  value={formData.defaultServerId}
                  onChange={(e) => setFormData({ ...formData, defaultServerId: e.target.value })}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-white text-xs font-semibold focus:outline-none focus:border-red-500"
                >
                  {STREAM_SERVERS.map((srv) => (
                    <option key={srv.id} value={srv.id}>
                      {srv.name} ({srv.badge})
                    </option>
                  ))}
                </select>
              </div>

              {/* Reset Locker Cache */}
              <div className="pt-2 flex justify-between items-center text-xs">
                <button
                  type="button"
                  onClick={handleClearUnlocks}
                  className="text-amber-400 hover:text-amber-300 underline font-medium"
                >
                  Reset all Media Unlock states (Test Locker again)
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="text-neutral-400 hover:text-white flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset to Defaults</span>
                </button>
              </div>

              {/* Save Button */}
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-[#e50914] hover:bg-[#b80710] text-white font-bold text-xs shadow-lg shadow-red-700/30 flex items-center justify-center gap-2 transition-all"
              >
                {savedSuccess ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                    <span>Settings Saved!</span>
                  </>
                ) : (
                  <span>Save Configuration</span>
                )}
              </button>
            </form>
          ) : activeTab === 'download-pc' ? (
            <div className="space-y-4 text-neutral-300 leading-relaxed">
              {/* Main Download Card */}
              <div className="p-4 bg-gradient-to-br from-neutral-900 via-neutral-900 to-black rounded-xl border border-red-600/40 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30">
                    <Laptop className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">Khrej l-project كامل l-PC dyalek (Full Source Code)</h3>
                    <p className="text-neutral-400 text-xs">Fichier ZIP fih ga3 l-fichiers, components, TMDB API, w 6 stream servers.</p>
                  </div>
                </div>

                <a
                  href="/flixstream.zip"
                  download="flixstream-project.zip"
                  className="w-full py-3 px-4 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-sm rounded-xl shadow-xl shadow-red-600/30 flex items-center justify-center gap-2 transition-all group"
                >
                  <Download className="w-4 h-4 group-hover:animate-bounce" />
                  <span>Télécharger FlixStream (ZIP - 35 KB)</span>
                </a>
              </div>

              {/* Step by Step Instructions */}
              <div className="space-y-3">
                <div className="p-3.5 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-red-600 text-white text-xs flex items-center justify-center font-bold">1</span>
                    <span>Décompresser l-fichier ZIP:</span>
                  </div>
                  <p className="text-neutral-400 text-xs pl-7">
                    Dir extrait (Extract Here) l hadak l-fichier <code className="text-red-400 font-mono">flixstream.zip</code> f ay dossier f ton PC (b7al Bureau aw Documents).
                  </p>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-red-600 text-white text-xs flex items-center justify-center font-bold">2</span>
                    <span>Installer Node.js:</span>
                  </div>
                  <p className="text-neutral-400 text-xs pl-7">
                    Khas ykoun 3ndk <strong>Node.js (v18+)</strong> f ton PC. Ila ma kanx 3ndk, telechargih f d9i9a mn: <a href="https://nodejs.org" target="_blank" rel="noreferrer" className="text-red-400 underline font-semibold">nodejs.org</a>.
                  </p>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-red-600 text-white text-xs flex items-center justify-center font-bold">3</span>
                    <span>Kheddem l-projet b 2 awamir f Terminal / CMD:</span>
                  </div>
                  <div className="pl-7 space-y-2">
                    <p className="text-neutral-400 text-xs">7ell l-CMD / PowerShell f dak l-dossier w kteb:</p>
                    <div className="bg-black/90 p-3 rounded-lg border border-neutral-800 font-mono text-xs text-emerald-400 space-y-1">
                      <div className="flex items-center gap-2 text-neutral-400">
                        <Terminal className="w-3.5 h-3.5" />
                        <span># 1. Install ga3 les packages</span>
                      </div>
                      <div className="text-white font-bold select-all">npm install</div>
                      <div className="flex items-center gap-2 text-neutral-400 pt-1">
                        <Terminal className="w-3.5 h-3.5" />
                        <span># 2. Lancer l-site f ton PC</span>
                      </div>
                      <div className="text-white font-bold select-all">npm run dev</div>
                    </div>
                    <p className="text-emerald-400 text-xs font-semibold">
                      ✓ L-site ghay-t7el direct f ton navigateur f: <code className="bg-neutral-800 px-1 py-0.5 rounded text-white">http://localhost:3000</code>
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-2">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">4</span>
                    <span>Kifach t-deployih f internet (Babat majaniyan):</span>
                  </div>
                  <p className="text-neutral-400 text-xs pl-7">
                    Kteb <code className="text-white font-mono bg-neutral-800 px-1 rounded">npm run build</code>, w telechargi l-dossier <code className="text-emerald-400 font-mono">dist</code> direct f <strong>Vercel</strong>, <strong>Netlify</strong>, aw <strong>Cloudflare Pages</strong> b click wa7da w y-b9a khdam lik f internet 24/7!
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-neutral-300 leading-relaxed">
              <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800 space-y-2">
                <div className="font-bold text-white text-sm flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-red-500" />
                  <span>Tari9a li khdam biha FlixStream (Moroccan Darija Guide):</span>
                </div>
                <p>
                  Had l-website kay-sta3mel 3 dyal l-arkane assasiyin bach ykhdem bla ma y-stoki video wa7da f server:
                </p>
              </div>

              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800">
                  <div className="font-bold text-white mb-1">1. TMDB API (The Movie Database):</div>
                  <p className="text-neutral-400 text-xs">
                    Kay-jbed biha l-catalogue kamel: Trending movies, Top Rated, Posters (w500), Backdrops (original), Synopsis, Rating, w TV series. Kol film 3ndo <code className="text-red-400">id</code> khass bih (mital: 12 Angry Men 3ndo <code className="text-red-400">id=389</code>).
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800">
                  <div className="font-bold text-white mb-1">2. Embed Stream Servers (VidSrc, VidLink, AutoEmbed...):</div>
                  <p className="text-neutral-400 text-xs">
                    Kay-khdem b iframe embedding direct mn servers li deja fihom les films f CDN bla tachfir:
                  </p>
                  <ul className="list-disc list-inside mt-1 space-y-1 font-mono text-[11px] text-neutral-300">
                    <li>https://vidsrc.to/embed/movie/$&#123;id&#125;</li>
                    <li>https://vidlink.pro/movie/$&#123;id&#125;</li>
                    <li>https://player.autoembed.cc/embed/movie/$&#123;id&#125;</li>
                  </ul>
                </div>

                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800">
                  <div className="font-bold text-white mb-1">3. The 15-Second Hook & Locker (OGAds CPA):</div>
                  <p className="text-neutral-400 text-xs">
                    L-visitor kay-bda y-tfrej f l-film 3adi (1080p). F 15 tanya, kay-tla3 modal dyal OGAds Locker m3a SubIDs tracking:
                    <br />
                    <code className="text-amber-300">https://appcomplete.org/cl/i/4o7vvr?aff_sub=12-angry-men&aff_sub2=389</code>
                    <br />
                    Mn be3d ma l-user ykmml offer, kay-tstoka <code className="text-emerald-400">localStorage.setItem('unlocked_389', 'true')</code> w kay-t7el l-film f 7alo bla ma y3awd y-tlbo locker mara khra.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
