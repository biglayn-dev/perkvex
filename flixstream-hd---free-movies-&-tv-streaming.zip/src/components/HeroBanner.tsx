import React from 'react';
import { Play, Info, Star, Clapperboard } from 'lucide-react';
import { MediaItem } from '../types';
import { TMDB_IMAGE_ORIGINAL, createSlug } from '../services/tmdb';

interface HeroBannerProps {
  movie: MediaItem | null;
  onWatch: (item: MediaItem) => void;
  onTrailer?: (item: MediaItem) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ movie, onWatch, onTrailer }) => {
  if (!movie) {
    return (
      <div className="relative w-full h-[65vh] md:h-[75vh] bg-[#141414] animate-pulse flex items-center px-6 md:px-16">
        <div className="space-y-4 max-w-xl">
          <div className="h-6 w-32 bg-neutral-800 rounded"></div>
          <div className="h-12 w-80 bg-neutral-800 rounded"></div>
          <div className="h-20 w-96 bg-neutral-800 rounded"></div>
        </div>
      </div>
    );
  }

  const title = movie.title || movie.name || 'Featured Movie';
  const backdropUrl = movie.backdrop_path
    ? `${TMDB_IMAGE_ORIGINAL}${movie.backdrop_path}`
    : 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&auto=format&fit=crop&q=80';
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : '8.5';
  const year = (movie.release_date || movie.first_air_date || '').split('-')[0] || '2026';

  return (
    <section className="relative w-full h-[70vh] md:h-[82vh] bg-black overflow-hidden flex items-end md:items-center px-4 md:px-12 pb-16 md:pb-0">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={backdropUrl}
          alt={title}
          className="w-full h-full object-cover object-top filter brightness-90 transform scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Cinematic Vignette Gradients */}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-[#141414]/30 to-transparent" />
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-20 max-w-2xl text-left space-y-4 pt-16">
        <div className="flex items-center gap-2.5">
          <span className="bg-[#e50914] text-white text-[11px] font-black uppercase tracking-wider px-2.5 py-1 rounded shadow-lg shadow-red-600/50">
            #1 TRENDING TODAY
          </span>
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded border border-neutral-700">
            <Star className="w-3.5 h-3.5 fill-emerald-400" />
            <span>{rating} Rating</span>
          </div>
          <span className="text-xs text-neutral-300 font-semibold">{year}</span>
          <span className="text-xs text-neutral-400 border border-neutral-700 px-1.5 py-0.5 rounded">
            1080P HD
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl md:text-6xl font-black text-white leading-tight drop-shadow-2xl">
          {title}
        </h1>

        <p className="text-sm md:text-base text-neutral-200 line-clamp-3 leading-relaxed max-w-xl drop-shadow">
          {movie.overview ||
            'Experience the highest-rated movie streaming right now with multiple ultra-fast CDN mirrors, Dolby audio, and multi-subtitles.'}
        </p>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={() => onWatch(movie)}
            className="flex items-center gap-2.5 px-6 py-3.5 rounded-lg bg-[#e50914] hover:bg-[#b80710] text-white font-extrabold text-sm md:text-base shadow-xl shadow-red-600/40 hover:scale-105 active:scale-95 transition-all duration-200"
          >
            <Play className="w-5 h-5 fill-white ml-0.5" />
            <span>Watch Now</span>
          </button>

          {onTrailer && (
            <button
              onClick={() => onTrailer(movie)}
              className="flex items-center gap-2 px-5 py-3.5 rounded-lg bg-neutral-800/80 hover:bg-neutral-700/80 backdrop-blur-md text-white font-bold text-sm border border-neutral-600 hover:scale-105 active:scale-95 transition-all duration-200"
            >
              <Clapperboard className="w-4 h-4 text-red-400" />
              <span>Trailer</span>
            </button>
          )}

          <button
            onClick={() => onWatch(movie)}
            className="flex items-center gap-2 px-5 py-3.5 rounded-lg bg-white/20 hover:bg-white/30 backdrop-blur-md text-white font-bold text-sm border border-white/20 hover:scale-105 active:scale-95 transition-all duration-200"
          >
            <Info className="w-4 h-4" />
            <span>More Details</span>
          </button>
        </div>
      </div>
    </section>
  );
};
