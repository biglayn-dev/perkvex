import React, { useState, useEffect, useRef } from 'react';
import { Search, Settings, Film, Tv, Flame, Star, Bookmark, Play, X, ExternalLink, Download } from 'lucide-react';
import { MediaItem } from '../types';
import { searchMedia, TMDB_IMAGE_W300 } from '../services/tmdb';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onSelectMovie: (item: MediaItem) => void;
  onOpenSettings: () => void;
  onSearchQuery?: (q: string) => void;
  watchlistCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  onSelectMovie,
  onOpenSettings,
  onSearchQuery,
  watchlistCount,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<MediaItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle Search input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);
    if (onSearchQuery) onSearchQuery(val);

    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);

    if (val.trim().length >= 2) {
      setIsSearching(true);
      setShowSearchDropdown(true);
      searchTimeoutRef.current = setTimeout(async () => {
        const results = await searchMedia(val);
        setSearchResults(results.slice(0, 7));
        setIsSearching(false);
      }, 350);
    } else {
      setSearchResults([]);
      setShowSearchDropdown(false);
      setIsSearching(false);
    }
  };

  // Close search dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Quick 12 Angry Men sample item
  const sample12AngryMen: MediaItem = {
    id: 389,
    title: '12 Angry Men',
    overview: 'Twelve jurors in a New York City murder trial evaluate the evidence...',
    poster_path: '/ow3wq89wM8qd5X7hWKxiRfsFf9C.jpg',
    backdrop_path: '/qqHQsStV6exghCM7zbObuYBiYxw.jpg',
    release_date: '1957-04-10',
    vote_average: 8.5,
    media_type: 'movie',
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#141414]/95 backdrop-blur-md shadow-2xl border-b border-neutral-800/80 py-3'
          : 'bg-gradient-to-b from-black/90 via-black/50 to-transparent py-4'
      } px-4 md:px-10`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left Side: Brand Logo & Links */}
        <div className="flex items-center gap-6 md:gap-8">
          {/* Logo matching flixstream */}
          <button
            onClick={() => onTabChange('home')}
            className="flex items-center gap-1 group text-left"
          >
            <span className="text-2xl md:text-3xl font-black tracking-wider text-[#e50914] group-hover:scale-105 transition-transform">
              FLIX<span className="text-white">STREAM</span>
            </span>
            <span className="hidden sm:inline-block ml-1 text-[9px] font-black uppercase tracking-widest bg-red-600/30 text-red-400 border border-red-500/40 px-1.5 py-0.5 rounded">
              HD
            </span>
          </button>

          {/* Nav Links */}
          <nav className="hidden lg:flex items-center gap-5 text-xs font-semibold text-neutral-300">
            <button
              onClick={() => onTabChange('home')}
              className={`hover:text-white transition-colors ${
                currentTab === 'home' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onTabChange('movies')}
              className={`hover:text-white transition-colors flex items-center gap-1 ${
                currentTab === 'movies' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              <Film className="w-3.5 h-3.5 text-neutral-400" />
              <span>Movies</span>
            </button>
            <button
              onClick={() => onTabChange('tv')}
              className={`hover:text-white transition-colors flex items-center gap-1 ${
                currentTab === 'tv' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              <Tv className="w-3.5 h-3.5 text-neutral-400" />
              <span>TV Series</span>
            </button>
            <button
              onClick={() => onTabChange('trending')}
              className={`hover:text-white transition-colors flex items-center gap-1 ${
                currentTab === 'trending' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-red-500" />
              <span>Trending</span>
            </button>
            <button
              onClick={() => onTabChange('top-rated')}
              className={`hover:text-white transition-colors flex items-center gap-1 ${
                currentTab === 'top-rated' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              <Star className="w-3.5 h-3.5 text-amber-400" />
              <span>Top Rated</span>
            </button>
            <button
              onClick={() => onTabChange('watchlist')}
              className={`hover:text-white transition-colors flex items-center gap-1 ${
                currentTab === 'watchlist' ? 'text-white font-bold border-b-2 border-red-600 pb-1' : ''
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-neutral-400" />
              <span>Watchlist</span>
              {watchlistCount > 0 && (
                <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                  {watchlistCount}
                </span>
              )}
            </button>
          </nav>
        </div>

        {/* Right Side: 12 Angry Men Quick Link, Search & Settings */}
        <div className="flex items-center gap-3">
          {/* Quick link to test 12 Angry Men matching user's exact requested URL */}
          <button
            onClick={() => onSelectMovie(sample12AngryMen)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900/90 hover:bg-neutral-800 border border-neutral-700/80 text-xs font-semibold text-neutral-200 hover:text-white transition-all shadow-sm group"
            title="Open 12 Angry Men (id=389) stream"
          >
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span>Watch 12 Angry Men</span>
          </button>

          {/* Search Box */}
          <div ref={searchRef} className="relative">
            <div className="relative flex items-center">
              <input
                type="text"
                placeholder="Search movies & series..."
                value={searchTerm}
                onChange={handleSearchChange}
                onFocus={() => {
                  if (searchResults.length > 0) setShowSearchDropdown(true);
                }}
                className="w-36 sm:w-56 md:w-64 bg-black/60 focus:bg-black/90 text-white placeholder-neutral-400 text-xs px-3.5 py-2 pl-9 rounded-full border border-neutral-700 focus:border-red-600 focus:outline-none focus:ring-1 focus:ring-red-600 transition-all duration-300"
              />
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 pointer-events-none" />
              {searchTerm && (
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setSearchResults([]);
                    setShowSearchDropdown(false);
                    if (onSearchQuery) onSearchQuery('');
                  }}
                  className="absolute right-3 text-neutral-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Instant Search Dropdown */}
            {showSearchDropdown && searchResults.length > 0 && (
              <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-[#1a1a1a] border border-neutral-700 rounded-xl shadow-2xl overflow-hidden z-50 divide-y divide-neutral-800 max-h-96 overflow-y-auto">
                <div className="p-2 text-[10px] font-bold uppercase tracking-wider text-neutral-400 bg-neutral-900/90 flex justify-between">
                  <span>Search Results</span>
                  <span>{searchResults.length} found</span>
                </div>
                {searchResults.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      onSelectMovie(item);
                      setShowSearchDropdown(false);
                      setSearchTerm('');
                    }}
                    className="p-2.5 flex items-center gap-3 hover:bg-neutral-800/90 cursor-pointer transition-colors group"
                  >
                    <img
                      src={
                        item.poster_path
                          ? `${TMDB_IMAGE_W300}${item.poster_path}`
                          : 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=100'
                      }
                      alt={item.title || item.name}
                      className="w-10 h-14 object-cover rounded shadow group-hover:scale-105 transition-transform"
                    />
                    <div className="flex-1 min-w-0 text-left">
                      <div className="text-xs font-bold text-white truncate group-hover:text-red-400 transition-colors">
                        {item.title || item.name}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-0.5">
                        <span className="text-emerald-400 font-semibold">
                          ★ {item.vote_average ? item.vote_average.toFixed(1) : 'N/A'}
                        </span>
                        <span>
                          {(item.release_date || item.first_air_date || '').split('-')[0] || 'HD'}
                        </span>
                        <span className="uppercase text-[9px] bg-neutral-800 px-1 py-0.2 rounded font-mono">
                          {item.media_type || 'movie'}
                        </span>
                      </div>
                    </div>
                    <Play className="w-4 h-4 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Export Project ZIP Button */}
          <a
            href="/flixstream.zip"
            download="flixstream-project.zip"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold text-neutral-200 hover:text-white border border-neutral-700/80 rounded-lg transition-all shadow-sm group"
            title="Download complete project source code for your PC (ZIP)"
          >
            <Download className="w-3.5 h-3.5 text-red-500 group-hover:animate-bounce" />
            <span className="hidden sm:inline">Download ZIP</span>
          </a>

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-full bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700/80 transition-all hover:rotate-45"
            title="Locker & API Settings (I3dadat)"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
