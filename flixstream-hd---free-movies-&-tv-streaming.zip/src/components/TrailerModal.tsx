import React from 'react';
import { X } from 'lucide-react';
import { MediaItem } from '../types';

interface TrailerModalProps {
  media: MediaItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export const TrailerModal: React.FC<TrailerModalProps> = ({ media, isOpen, onClose }) => {
  if (!isOpen || !media) return null;

  // Look for YouTube Trailer in media.videos.results
  const trailer =
    media.videos?.results?.find(
      (v) => v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser')
    ) || media.videos?.results?.[0];

  const title = media.title || media.name || 'Official Trailer';

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#181818] border border-neutral-800 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="font-bold text-sm md:text-base text-white truncate">
            {title} - Official Trailer
          </h3>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player */}
        <div className="relative aspect-video w-full bg-black">
          {trailer?.key ? (
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${trailer.key}?autoplay=1`}
              title={title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-neutral-400 p-6 text-center">
              <p className="text-sm font-semibold text-white mb-1">Trailer Not Available on TMDB</p>
              <p className="text-xs text-neutral-500">
                You can start watching the full HD movie directly on the stream player!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
