export interface MediaItem {
  id: number;
  title?: string;
  name?: string; // For TV
  original_title?: string;
  original_name?: string;
  overview: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  vote_count?: number;
  media_type?: 'movie' | 'tv';
  genre_ids?: number[];
  genres?: { id: number; name: string }[];
  runtime?: number;
  number_of_seasons?: number;
  number_of_episodes?: number;
  tagline?: string;
  status?: string;
  credits?: {
    cast?: { id: number; name: string; character: string; profile_path: string | null }[];
    crew?: { id: number; name: string; job: string }[];
  };
  videos?: {
    results?: {
      id: string;
      key: string;
      name: string;
      site: string;
      type: string;
    }[];
  };
  similar?: {
    results?: MediaItem[];
  };
}

export interface TVSeason {
  season_number: number;
  name: string;
  episode_count: number;
  air_date?: string;
  episodes?: TVEpisode[];
}

export interface TVEpisode {
  id: number;
  episode_number: number;
  season_number: number;
  name: string;
  overview: string;
  still_path?: string | null;
  vote_average?: number;
  runtime?: number;
}

export interface StreamServer {
  id: string;
  name: string;
  badge: string;
  tag: string;
  isPopular?: boolean;
  getUrl: (mediaType: 'movie' | 'tv', id: number | string, season?: number, episode?: number) => string;
}

export interface AppSettings {
  tmdbApiKey: string;
  ogadsLockerId: string;
  ogadsEnabled: boolean;
  ogadsTimeoutSeconds: number;
  defaultServerId: string;
}

export interface WatchHistoryItem {
  id: number;
  title: string;
  poster_path?: string | null;
  media_type: 'movie' | 'tv';
  slug: string;
  season?: number;
  episode?: number;
  timestamp: number;
}
