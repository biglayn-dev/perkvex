# FlixStream HD — Complete Streaming Web App

A Netflix-style responsive movie and TV series streaming web application built with **React 19**, **TypeScript**, **Tailwind CSS**, and **Vite**.

## 🚀 Features
- 🎬 **6 Real Full Movie & TV Streaming Servers** (123Embed Ultra HD, AnyEmbed / SmashyStream, AutoEmbed CC, Videasy, VidSrc Prime, 2Embed).
- 🔒 **OGAds Content Locker Integration** with customizable 15-second timer hook and dynamic SubIDs (`aff_sub` = movie slug, `aff_sub2` = TMDB ID).
- 🍿 **Full Netflix-Style UI**: Hero Banner with backdrop trailers, Trending Movies, TV Series, Genre Tabs, Search, Watchlist, and History.
- ⚙️ **In-App Settings Panel**: Easily change your TMDB API Key, OGAds Locker ID (`4o7vvr`), Locker timer, and Default Server.
- 📱 **100% Responsive**: Seamlessly works on Desktop, Tablets, and Mobile phones.

---

## 💻 How to Run Locally on Your PC

### Prerequisites
Make sure you have **Node.js** (version 18 or higher) installed on your computer.
Download it from: [https://nodejs.org](https://nodejs.org)

### Step 1: Install Dependencies
Open your terminal (PowerShell, Command Prompt, or Terminal) in the project folder and run:
```bash
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

### Step 3: Open in Browser
Open your browser and navigate to:
```
http://localhost:3000
```
(or the port shown in your terminal, e.g., `http://localhost:5173`).

---

## 📦 How to Build for Production / Deployment

To build the optimized production files:
```bash
npm run build
```
This will generate a `dist` folder ready to be deployed on **Vercel**, **Netlify**, **Cloudflare Pages**, or any hosting server (cPanel / Apache / Nginx).

---

## 🛠 Project Structure
- `src/components/WatchCinema.tsx` — Full movie player engine, 6 servers switcher, OGAds 15s locker modal.
- `src/components/Navbar.tsx` — Header, search bar, settings modal trigger, download button.
- `src/components/SettingsModal.tsx` — In-browser settings (OGAds ID, TMDB Key, Default Server).
- `src/services/servers.ts` — 6 live full movie streaming endpoints.
- `src/services/tmdb.ts` — TMDB API service for trending, search, movies, and TV seasons.
- `src/services/storage.ts` — LocalStorage manager for settings, watchlist, and unlocked status.
